# X-Plane Harita Plugini — Proje Notu

## Amaç
X-Plane 11 içinde, Kaşif / OSM / dış navdata kullanmadan, sadece X-Plane'in
kendi verisi + OpenGL ile harita işlerinin ne kadarının yapılabildiğini
araştırmak (AR-GE). Hedef: haritada görülen pist, navaid, arazi simülatördekiyle
birebir aynı olsun.

İstenen yetenekler: pan/zoom, rota çizimi, haritaya tıklayıp nokta ve bölge
işaretleme, harita etrafında butonlarla yönetim.

## Çalışma şekli (önemli)
- Kullanıcı X-Plane plugin geliştirmeye yeni başlıyor ve kodu ANLAYARAK
  ilerlemek istiyor.
- Her seferinde tek küçük adım: az kod, her satırın ne yaptığı açıklanmış.
- Büyük, hazır kod blokları verme. Bir adım derlenip X-Plane'de test
  edilmeden sonrakine geçme.
- Açıklamalar Türkçe.

## Sabitler
- Simülatör: X-Plane 11 (SDK 3.0.x, XPLM300/301), Windows, 64-bit.
- Harita ayrı bir uygulama değil, X-Plane içinde çalışacak.
- Plugin dili: C++, derleme: CMake + Visual Studio 2022.
- Ekipte hazır bir apt.dat parse motoru var; yeniden yazılmayacak.
- SDK yolu: `-DXPSDK=<klasör>` ile verilir (varsayılan `C:/dev/XPSDK`).
  Sadece XPLM200..XPLM301 tanımlı: XP12'ye özel API kullanılırsa derleme hata verir.
- Kurulum yeri: `X-Plane 11/Resources/plugins/HaritaPlugin/64/win.xpl`.
- Kullanıcının X-Plane kurulum yolunu bilmiyoruz; gerekirse sor.

## Şimdiye kadar öğrenilenler
- X-Plane'in haritası diskte hazır bir görüntü değil; X-Plane onu kendi
  dosyalarından (DSF sahne + apt.dat + nav verisi) anlık çiziyor.
- SDK, harita görüntüsünü veya çizim motorunu başka pencereye vermiyor.
- XPLMMap API ile X-Plane'in KENDİ harita penceresine katman eklenebilir:
  zemin, zoom, pan, havalimanları, pistler, navaid/fix/havayolları, FMS rotası
  X-Plane'den hazır gelir. Biz üstüne OpenGL ile çizeriz.
- `XPLMMapProject` / `XPLMMapUnproject` lat/lon <-> harita koordinatı verir.
- XPLMMap katmanları fare tıklaması ALMAZ. Denenecek fikir: çizim callback'inde
  OpenGL matrisleri + `XPLMGetMouseLocationGlobal` ile imlecin lat/lon'unu
  hesaplamak; "tıklama" yerine bir klavye komutuyla nokta eklemek.
- Bu yetmezse plan B: kendi pencere (`XPLMCreateWindowEx`) + zemini DSF'ten
  offline üretmek (DSFTool / DSFLib). Şimdilik bu yola girilmiyor.
- XP11 haritasının yaklaşma prosedürlerini kendiliğinden çizip çizmediği
  bilinmiyor; testte bakılacak.

## Durum (sürüm 0.3)
- Kullanıcı tüm planın tek seferde yazılmasını istedi; sürüm 0.2 yazıldı.
  Dosya görevleri ve test listesi README.md'de.
- Tasarım: XPLMMap katmanı çizer; katmanın draw callback'i OpenGL matrisini
  ve `bounds`'u kaydeder -> haritanın ekrandaki dikdörtgeni hesaplanır
  (scissor kutusu varsa onunla kesişim). Bu dikdörtgene her karede
  görünmez XPLM penceresi (ClickWindow) oturtulur, sadece işaretleme
  modunda görünür (X-Plane tıklama geçirmeyi önermiyor). Buton paneli
  haritanın soluna/sağına yapışır. Boxel<->piksel dönüşümü kendi
  pencerelerimiz çizilirken okunur (UI ölçek otomatik).
- Tıklama lat/lon'a bir sonraki harita çiziminde çevrilir
  (XPLMMapUnproject sadece harita callback'i içinde geçerli).
- X-Plane'siz testler geçiyor (tests/tests.cpp: matris senaryoları,
  UI ölçek, dönük harita, üçgenleme, çizim modeli).
- MinGW ile gerçek SDK'ya karşı win.xpl derlendi; MSVC ile derlenmedi.
- 0.2 X-Plane'de denendi: hizalama ve tıklama ÇALIŞIYOR (mavi çerçeve
  harita kenarına oturuyor, P/R/B çizimleri doğru yerde). Sorun: dolu
  şekiller (panel zemini, butonlar, nokta işaretleri, bölge dolgusu)
  görünmüyordu; muhtemel neden X-Plane'in açık bıraktığı GL_CULL_FACE.
- 0.3: çizim sırasında GL_CULL_FACE kapatılıyor (GLInclude.h CullFaceOff),
  panel yeniden tasarlandı, noktalar OpenGL işaretiyle çiziliyor; X-Plane
  ikon fonksiyonu sadece teşhis modunda. 0.3 henüz X-Plane'de denenmedi.

## Sıradaki
1. [ ] Kullanıcı README'deki 18 maddelik test listesini X-Plane'de uygulasın
2. [ ] Kayma varsa teşhis modu Log.txt `TESHIS` satırlarıyla düzelt
3. [ ] Bulguları rapora işle (kullanıcının xplmap_notes.txt notları +
       Claude Docs raporu): neler doğrulandı / denenecek
4. [ ] Sonra: çizimleri kaydet/yükle, kendi DB'den rota çizme

## İlgili
- Ekip raporu (Claude Docs): "X-Plane Harita Plugini: Neler Yapılabilir,
  Neler Yapılamaz"
